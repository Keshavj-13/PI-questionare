# API Endpoints for PI Q&A Site Backend

## Authentication
- `POST /api/auth/google` — Authenticate user with Google token, return user info and JWT.
- `POST /api/auth/logout` — Log out user (optional for stateless JWT).

## User Profile
- `GET /api/users/me` — Get current user's profile (requires auth).
- `GET /api/users/:id` — Get public profile for user by ID.
- `PATCH /api/users/me` — Update current user's profile (name, avatar, etc).

## Questions
- `GET /api/questions` — List all questions (with optional filters: topic, search, pagination).
- `GET /api/questions/:id` — Get a single question by ID (with answers).
- `POST /api/questions` — Create a new question (requires auth; accepts text, image, topic).
- `DELETE /api/questions/:id` — Delete a question (owner or admin only).

## Answers
- `POST /api/questions/:id/answers` — Post an answer to a question (requires teacher role).
- `DELETE /api/answers/:id` — Delete an answer (owner or admin only).

## Images
- `POST /api/upload` — Upload an image (returns URL or base64; used for question images).

## Topics
- `GET /api/topics` — List all available topics.

## Admin (optional)
- `GET /api/admin/users` — List all users (admin only).
- `PATCH /api/admin/users/:id/role` — Change user role (admin only).

---

## Notes
- All endpoints starting with `/api/`.
- Auth required for posting questions/answers, updating profile, etc.
- Use JWT or session for authentication.
- Image upload can be base64 or multipart/form-data.
- Extend as needed for notifications, moderation, etc.
