// QnA Front‑end script – updated to match the Spring‑Boot 3 backend
// ===============================================================
//  *   Uses JWT auth (token stored in localStorage)
//  *   Calls real REST endpoints: /api/questions, /api/questions/{id}/answers, /api/topics
//  *   Teacher‐only answer form appears when logged‑in user role === "TEACHER"
//  *   Image upload handled in one step after question creation
// ---------------------------------------------------------------

// Helper DOM selectors
const $ = (sel, p = document) => p.querySelector(sel);
const $$ = (sel, p = document) => [...p.querySelectorAll(sel)];

// Base API root (adjust if backend runs on a different host/port)
const API = ""; // empty = same origin; change to "http://localhost:8080" if you proxy differently

// ---------------------------------------------------------------
// Auth helpers
// ---------------------------------------------------------------
const auth = {
  get token() {
    return localStorage.getItem("token") || null;
  },
  get user() {
    const raw = localStorage.getItem("user");
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  },
  headers() {
    return this.token ? { Authorization: "Bearer " + this.token } : {};
  },
};

// ---------------------------------------------------------------
// App module
// ---------------------------------------------------------------
const App = (() => {
  const state = { questions: [] };
  const dom = {};

  const cache = () => {
    dom.feed = $("#feed");
    dom.modal = $("#modal");
    dom.askBtn = $("#askBtn");
    dom.cancelBtn = $("#cancelBtn");
    dom.postBtn = $("#postBtn");
    dom.questionInput = $("#questionInput");
    dom.search = $("#searchInput");
    dom.year = $("#year");
    dom.cats = $$(".category");
    dom.avatar = $("#accountBtn");
  };

  // ----------------------------------------------------------------
  // Render helpers
  // ----------------------------------------------------------------
  const isTeacher = () => auth.user && (auth.user.role === "TEACHER" || auth.user.role === "teacher");

  const ytEmbed = (text) => {
    const m = text.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)([\w-]{11})/);
    return m ? `<iframe width="320" height="180" src="https://www.youtube.com/embed/${m[1]}" frameborder="0" allowfullscreen></iframe>` : null;
  };

  const renderAnswer = (a) => {
    const embed = ytEmbed(a.body);
    const bodyHtml = embed ? embed : a.body;
    return `<div class="answer"><strong>${a.author}</strong><br>${bodyHtml}</div>`;
  };

  const render = (list) => {
    dom.feed.innerHTML = list
      .map((q) => {
        const answerForm = isTeacher()
          ? `<form class="answer-form" data-qid="${q.id}">
               <input class="answer-input" placeholder="Type answer…" required>
               <button type="submit" class="btn-primary">Post</button>
             </form>`
          : "";
        const imageTag = q.imageUrl ? `<img src="${q.imageUrl}" alt="img" class="q-image"/>` : "";
        return `
          <div class="card">
            <h3>${q.title}</h3>
            ${imageTag}
            <p>${q.content}</p>
            <div class="meta">asked by ${q.author} · ${q.topic ?? "General"}</div>
            <button class="btn-secondary toggleAns">${q.answerCount} answers</button>
            <div class="answers" style="display:none;">${(q.answers || []).map(renderAnswer).join("")}${answerForm}</div>
          </div>`;
      })
      .join("");

    $$(".toggleAns", dom.feed).forEach((b) =>
      b.addEventListener("click", () => {
        const ans = b.nextElementSibling;
        ans.style.display = ans.style.display === "block" ? "none" : "block";
      })
    );

    if (isTeacher()) {
      $$(".answer-form", dom.feed).forEach((f) =>
        f.addEventListener("submit", async (e) => {
          e.preventDefault();
          const qid = f.dataset.qid;
          const input = $(".answer-input", f);
          const body = input.value.trim();
          if (!body) return;
          await postAnswer(qid, body);
          input.value = "";
        })
      );
    }
  };

  // ----------------------------------------------------------------
  // Backend calls
  // ----------------------------------------------------------------
  const fetchQuestions = async () => {
    const res = await fetch(`${API}/api/questions`);
    const data = await res.json();
    state.questions = data.map((q) => ({
      id: q.id,
      title: q.title,
      content: q.content,
      author: q.author,
      topic: q.topic,
      imageUrl: q.imageUrls && q.imageUrls.length ? q.imageUrls[0] : null,
      answerCount: q.answerCount ?? (q.answers ? q.answers.length : 0),
      answers: q.answers ?? [],
    }));
    render(state.questions);
  };

  const postAnswer = async (questionId, body) => {
    const form = { body };
    const res = await fetch(`${API}/api/questions/${questionId}/answers`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...auth.headers(),
      },
      body: JSON.stringify(form),
    });
    if (res.ok) await fetchQuestions();
    else alert("Failed to post answer (are you logged in as teacher?)");
  };

  const postQuestion = async ({ title, content, topicId, imageFile }) => {
    // 1. Create question without image first
    const createRes = await fetch(`${API}/api/questions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...auth.headers(),
      },
      body: JSON.stringify({ title, content, topicId }),
    });
    if (!createRes.ok) throw new Error("Question create failed");
    const q = await createRes.json();

    // 2. If image selected, upload to /api/questions/{id}/images
    if (imageFile) {
      const fd = new FormData();
      fd.append("file", imageFile);
      const imgRes = await fetch(`${API}/api/questions/${q.id}/images`, {
        method: "POST",
        headers: auth.headers(),
        body: fd,
      });
      if (!imgRes.ok) alert("Image upload failed; question saved without image");
    }
    await fetchQuestions();
  };

  // ----------------------------------------------------------------
  // UI event listeners
  // ----------------------------------------------------------------
  const listen = () => {
    dom.search?.addEventListener("input", () => {
      const term = dom.search.value.toLowerCase();
      render(state.questions.filter((q) => q.title.toLowerCase().includes(term)));
    });

    dom.askBtn?.addEventListener("click", () => {
      dom.modal.classList.add("active");
      dom.questionInput.focus();
    });
    dom.cancelBtn?.addEventListener("click", () => dom.modal.classList.remove("active"));
    dom.modal?.addEventListener("click", (e) => {
      if (e.target === dom.modal) dom.modal.classList.remove("active");
    });

    dom.cats.forEach((c) =>
      c.addEventListener("click", () => {
        render(state.questions.filter((q) => q.topic === c.dataset.topic));
      })
    );

    dom.avatar?.addEventListener("click", () => {
      if (auth.token) window.location.href = "profile.html";
      else window.location.href = "login.html";
    });

    // Ask form on ask.html
    if (window.location.pathname.endsWith("ask.html")) {
      const askForm = $("#askForm");
      askForm?.addEventListener("submit", async (e) => {
        e.preventDefault();
        const title = $("textarea[name='title']", askForm).value.trim();
        const content = $("textarea[name='content']", askForm).value.trim();
        const topicId = $("select[name='topic']", askForm).value || null;
        const imgInput = $("#questionImage", askForm);
        const file = imgInput?.files[0] || null;
        try {
          await postQuestion({ title, content, topicId, imageFile: file });
          alert("Question posted!");
          window.location.href = "index.html";
        } catch {
          alert("Could not post question.");
        }
      });
    }
  };

  const init = () => {
    cache();
    fetchQuestions();
    listen();
    dom.year && (dom.year.textContent = new Date().getFullYear());
  };

  return { init };
})();

document.addEventListener("DOMContentLoaded", App.init);
