package com.pi.qna.dto;

public record UserDto(Long id, String username, String role) { }
