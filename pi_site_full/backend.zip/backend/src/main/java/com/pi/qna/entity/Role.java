package com.pi.qna.entity;

public enum Role {
    STUDENT,
    TEACHER,
    ADMIN
}