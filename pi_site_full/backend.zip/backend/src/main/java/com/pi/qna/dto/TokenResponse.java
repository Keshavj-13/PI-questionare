package com.pi.qna.dto;

public record TokenResponse(String token) { }
