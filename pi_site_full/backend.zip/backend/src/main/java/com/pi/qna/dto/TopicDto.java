package com.pi.qna.dto;

public record TopicDto(Long id, String name) { }
