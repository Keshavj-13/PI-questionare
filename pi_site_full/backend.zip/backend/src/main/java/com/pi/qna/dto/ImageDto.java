package com.pi.qna.dto;

public record ImageDto(Long id, String url) { }
